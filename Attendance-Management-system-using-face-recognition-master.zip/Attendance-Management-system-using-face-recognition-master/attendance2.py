import tkinter as tk
from tkinter import *
import os, cv2
import mysql.connector
import shutil
import numpy as np
from PIL import ImageTk, Image
import pyttsx3
import datetime

# Project modules
import show_attendance
import takeImage
import trainImage
import automaticAttedance

def connect_db():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root", 
            password="", 
            database="video_streaming"
        )
        return conn
    except mysql.connector.Error as err:
        print("Database Connection Error:", err)
        return None

def text_to_speech(user_text):
    engine = pyttsx3.init()
    engine.say(user_text)
    engine.runAndWait()

haarcasecade_path = "haarcascade_frontalface_default.xml"
trainimagelabel_path = "./TrainingImageLabel/Trainner.yml"
trainimage_path = "./TrainingImage"
attendance_path = "Attendance"

os.makedirs(trainimage_path, exist_ok=True)

window = Tk()
window.title("Face Recognizer")
window.geometry("1280x720")
window.configure(background="#1c1c1c")

def err_screen():
    sc1 = tk.Toplevel()
    sc1.geometry("400x110")
    sc1.title("Warning!!")
    sc1.configure(background="#1c1c1c")
    tk.Label(sc1, text="Enrollment & Name required!!!", fg="yellow", bg="#1c1c1c", font=("Verdana", 16, "bold")).pack()
    tk.Button(sc1, text="OK", command=sc1.destroy, fg="yellow", bg="#333333", width=9, height=1, activebackground="red", font=("Verdana", 16, "bold")).place(x=110, y=50)

def register_student(enrollment_no, name, message):
    if not enrollment_no or not name:
        err_screen()
        return
    
    image_path = f"{trainimage_path}/{enrollment_no}.jpg"
    
    conn = connect_db()
    if conn is None:
        message.config(text="Database connection failed!", fg="red")
        return

    try:
        cursor = conn.cursor()
        sql = "INSERT INTO students (enrollment_no, name, image_path) VALUES (%s, %s, %s)"
        cursor.execute(sql, (enrollment_no, name, image_path))
        conn.commit()
        message.config(text="Student Registered Successfully!", fg="green")
        text_to_speech("Student registered successfully!")
    except mysql.connector.Error as err:
        message.config(text="Error: " + str(err), fg="red")
    finally:
        cursor.close()
        conn.close()

def TakeImageUI():
    ImageUI = Toplevel()
    ImageUI.title("Take Student Image")
    ImageUI.geometry("780x480")
    ImageUI.configure(background="#1c1c1c")

    tk.Label(ImageUI, text="Register Your Face", bg="#1c1c1c", fg="green", font=("Verdana", 30, "bold")).place(x=270, y=12)
    tk.Label(ImageUI, text="Enter the details", bg="#1c1c1c", fg="yellow", font=("Verdana", 24, "bold")).place(x=280, y=75)

    tk.Label(ImageUI, text="Enrollment No", bg="#1c1c1c", fg="yellow", font=("Verdana", 14)).place(x=120, y=130)
    txt1 = tk.Entry(ImageUI, width=17, bg="#333333", fg="yellow", font=("Verdana", 18, "bold"))
    txt1.place(x=250, y=130)

    tk.Label(ImageUI, text="Name", bg="#1c1c1c", fg="yellow", font=("Verdana", 14)).place(x=120, y=200)
    txt2 = tk.Entry(ImageUI, width=17, bg="#333333", fg="yellow", font=("Verdana", 18, "bold"))
    txt2.place(x=250, y=200)

    message = tk.Label(ImageUI, text="", width=32, height=2, bg="#333333", fg="yellow", font=("Verdana", 14, "bold"))
    message.place(x=250, y=270)

    def take_image():
        enrollment_no, name = txt1.get(), txt2.get()
        register_student(enrollment_no, name, message)
        takeImage.TakeImage(enrollment_no, name, haarcasecade_path, trainimage_path, message, err_screen, text_to_speech)
        txt1.delete(0, "end")
        txt2.delete(0, "end")

    tk.Button(ImageUI, text="Take Image", command=take_image, bg="#333333", fg="yellow", font=("Verdana", 18, "bold"), height=2, width=12).place(x=130, y=350)

    def train_image():
        trainImage.TrainImage(haarcasecade_path, trainimage_path, trainimagelabel_path, message, text_to_speech)

    tk.Button(ImageUI, text="Train Image", command=train_image, bg="#333333", fg="yellow", font=("Verdana", 18, "bold"), height=2, width=12).place(x=360, y=350)

def automatic_attedance():
    automaticAttedance.subjectChoose(record_attendance)

def view_attendance():
    show_attendance.subjectchoose(text_to_speech)

tk.Button(window, text="Register a new student", command=TakeImageUI, bg="black", fg="yellow", font=("Verdana", 16), height=2, width=17).place(x=100, y=520)
tk.Button(window, text="Take Attendance", command=automatic_attedance, bg="black", fg="yellow", font=("Verdana", 16), height=2, width=17).place(x=600, y=520)
tk.Button(window, text="View Attendance", command=view_attendance, bg="black", fg="yellow", font=("Verdana", 16), height=2, width=17).place(x=1000, y=520)
tk.Button(window, text="EXIT", command=window.quit, bg="red", fg="white", font=("Verdana", 16), height=2, width=17).place(x=550, y=620)

window.mainloop()