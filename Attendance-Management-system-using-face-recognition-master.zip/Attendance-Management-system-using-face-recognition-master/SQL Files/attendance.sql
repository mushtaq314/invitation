-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2025 at 06:59 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `video_streaming`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `enrollment_no` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `enrollment_no`, `name`, `image_path`, `timestamp`) VALUES
(1, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:10:30'),
(2, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:10:33'),
(3, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:10:38'),
(4, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:10:51'),
(5, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:17:13'),
(6, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:17:24'),
(7, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:18:47'),
(8, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:18:51'),
(9, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:18:58'),
(10, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:19:03'),
(11, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:19:05'),
(12, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:19:09'),
(13, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:19:14'),
(14, '4', 'Prajakta', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_85cfcacdb65a4c0ab2452ae7009bec8d.jpg', '2025-03-18 11:19:16'),
(15, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:19:33'),
(16, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:19:36'),
(17, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:19:38'),
(18, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:19:42'),
(19, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:19:45'),
(20, '3', 'Ritu', 'C:/Users/Admin/Desktop/imagedetect1/static/uploads/img2_8bde811be902432bad397c3b50205275.jpg', '2025-03-18 11:19:47');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
