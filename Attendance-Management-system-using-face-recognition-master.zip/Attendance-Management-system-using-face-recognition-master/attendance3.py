import tkinter as tk
from tkinter import *
import os, cv2, time
import mysql.connector
import numpy as np
from PIL import ImageTk, Image
import pyttsx3
import datetime

def connect_db():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",
            database="video_streaming"
        )
        return conn
    except mysql.connector.Error as err:
        print("Database Connection Error:", err)
        return None

def text_to_speech(user_text):
    engine = pyttsx3.init()
    engine.say(user_text)
    engine.runAndWait()

# Paths
haarcasecade_path = "haarcascade_frontalface_default.xml"
trainimagelabel_path = "./TrainingImageLabel/Trainner.yml"
os.makedirs("./TrainingImage", exist_ok=True)

def recognize_face():
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    recognizer.read(trainimagelabel_path)
    face_cascade = cv2.CascadeClassifier(haarcasecade_path)
    cap = cv2.VideoCapture(0)
    time.sleep(2)  # Wait 2 seconds before face detection
    
    conn = connect_db()
    if conn is None:
        return
    
    cursor = conn.cursor()
    cursor.execute("SELECT enrollment_no, name, image_path FROM students")
    students = {row[0]: (row[1], row[2]) for row in cursor.fetchall()}
    
    while True:
        ret, img = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)
        
        for (x, y, w, h) in faces:
            id_, conf = recognizer.predict(gray[y:y+h, x:x+w])
            print(f"Detected ID: {id_}, Confidence: {conf}")
            if conf < 50 and id_ in students:
                name, image_path = students[id_]
                cv2.putText(img, name, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)
                record_attendance(id_, name, image_path)
        
        cv2.imshow("Face Recognizer", img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()
    cursor.close()
    conn.close()

def record_attendance(enrollment_no, name, image_path):
    conn = connect_db()
    if conn is None:
        return
    
    try:
        cursor = conn.cursor()
        timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        cursor.execute("INSERT INTO attendance (enrollment_no, name, image_path, timestamp) VALUES (%s, %s, %s, %s)", (enrollment_no, name, image_path, timestamp))
        conn.commit()
        print(f"Attendance recorded for {name}")
        text_to_speech(f"Attendance recorded for {name}")
    except mysql.connector.Error as err:
        print("Error:", err)
    finally:
        cursor.close()
        conn.close()

# UI Elements
window = Tk()
window.title("Face Recognizer")
window.geometry("1280x720")
window.configure(background="#1c1c1c")

tk.Button(window, text="Start Attendance", command=recognize_face, bg="black", fg="yellow", font=("Verdana", 16), height=2, width=17).place(x=600, y=520)
tk.Button(window, text="EXIT", command=window.quit, bg="red", fg="white", font=("Verdana", 16), height=2, width=17).place(x=550, y=620)

window.mainloop()

