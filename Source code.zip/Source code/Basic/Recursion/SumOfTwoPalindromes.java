package Recursion;

public class SumOfTwoPalindromes {

    
    public static boolean isPalindrome(int num) {
        int original = num;
        int reversed = 0;

        while (num > 0) {
            int digit = num % 10;
            reversed = (reversed * 10) + digit;
            num = num / 10;
        }

        return original == reversed;
    }

  
    public static void checkPalindromeSum(int target) {
        for (int i = 1; i <= target; i++) {
            int j = target - i;  
           
            if (isPalindrome(i) && isPalindrome(j)) {
                int sum = i + j;  
                if (sum == target) {
                    System.out.println("Found: " + i + " + " + j + " = " + sum);
                    
                }
            }
        }

        System.out.println("Number two palindromes found whose sum is " + target);
    }

    // Main method
    public static void main(String[] args) {
        int number = 130;
        checkPalindromeSum(number);
    }
}



