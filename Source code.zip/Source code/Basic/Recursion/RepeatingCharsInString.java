package Recursion;

class RepeatingCharsInString {
    public static void main(String args[]) {
        String charactersString = "aabadcb";// 3  b
        
        
        for(int i=0;i<=charactersString.length()-1;i++)
        {
            boolean isRepeated=false;
           for(int j=0;j<i;j++)
           {
            if(charactersString.charAt(i)==charactersString.charAt(j)){
                isRepeated=true;
                break;
            }
        }
            if(isRepeated)
            {
                continue;
            }

            for(int s=i+1;s<=charactersString.length()-1;s++)
            {
            if(charactersString.charAt(i)==charactersString.charAt(s)){
              System.out.println("Reapeted char::"+charactersString.charAt(i)); 
              break;
            }

           }            
        
       
    }
}

}

