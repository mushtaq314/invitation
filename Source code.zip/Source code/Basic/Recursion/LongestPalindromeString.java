package Recursion;

public class LongestPalindromeString {

    public static void main(String args[]) {
        String inputString = "forgeeksskeegfor";               
        String longestPalindrome = "";

       for(int i=0;i<inputString.length()-1;i++)
       {
        int c=0;
        for(int j=i;j<inputString.length()-1;j++)
        {
            String substr=inputString.substring(i, j+1);
            System.out.println(c+" substr::"+substr);
            c++;

            if(checkPalindrome(substr))
            {
               if(substr.length()>longestPalindrome.length())
               {
                longestPalindrome=substr;
                System.out.println("longest palindrome::"+longestPalindrome);
               }
            }
        }
       }

      System.out.println("longst palindrome is "+longestPalindrome);
    }
     public static boolean checkPalindrome(String getTempString)
       {
        int j=getTempString.length()-1;
        int i=0;
        while(i<j)
        {
            if(getTempString.charAt(i)!=getTempString.charAt(j))
            {
                return false;
            }
            i++;
            j--;
        }
        return true;
       }
}
