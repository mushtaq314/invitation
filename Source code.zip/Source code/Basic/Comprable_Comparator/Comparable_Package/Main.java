package Comprable_Comparator.Comparable_Package;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Student> list = new ArrayList<>();
        list.add(new Student("Alice", 22));
        list.add(new Student("Bob", 20));
        list.add(new Student("Charlie", 25));

        Collections.sort(list); // Uses compareTo

        System.out.println("Sorted by age (Comparable):");
        for (Student s : list) {
            System.out.println(s);
        }
    }
}
