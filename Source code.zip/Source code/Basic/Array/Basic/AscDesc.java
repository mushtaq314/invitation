public class AscDesc {
    public static void main(String[] args) {
         int array1[]={12,34,56,7,6,89,56,247,56,9,8,87};
         for (int i = 0; i < array1.length; i++) {
            for (int j =i+1; j < array1.length; j++) {
                if(array1[i]>array1[j])
                {
                    int temp=array1[j];
                    array1[j]=array1[i];
                    array1[i]=temp;
                }
            }
         }

         for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i]+",");
         }
         System.out.println();
System.out.println("------------------------------");
          for (int i = 0; i < array1.length; i++) {
            for (int j =i+1; j < array1.length; j++) {
                if(array1[i]<array1[j])
                {
                    int temp=array1[j];
                    array1[j]=array1[i];
                    array1[i]=temp;
                }
            }
         }

         for (int i = 0; i < array1.length; i++) {
            System.out.print(array1[i]+",");
         }
    }
    
}
