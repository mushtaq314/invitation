import java.util.Arrays;

public class ReverseArray {

  public static void main(String[] args) {
    int array1 []={12,45,56,43,67,97,3,7,7345,45};
  for (int i : array1) {
    System.out.print(i+",");
  }
  System.out.println("--------------------");
    int s=array1.length-1;
    for(int i=0;i<=array1.length/2;i++)
     {           int temp=array1[s];
           array1[s]=array1[i];
           array1[i]=temp;
       s--;
    
       
    
  }
       System.out.println(array1.toString());
  for (int i : array1) {
    System.out.print(i+",");
  }
    }
    
}
