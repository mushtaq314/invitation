package Collection.RealTimeExample;

// 3. Sort a List of Products by Price


import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
public class ListExample3 {
    public static void main(String[] args) {
        List<Double> price=new LinkedList<>(Arrays.asList(12.3,112.7,67.7,99.8));
        System.out.println("price of products");
        System.out.println(price.toString());
        
        List<Double> sorted_price=price.stream().sorted().collect(Collectors.toList());
        System.out.println("sorted price"+sorted_price.toString());
 
        System.out.println("sorting the price in descending");

         Collections.reverse(sorted_price);
        System.out.println(sorted_price.toString());




    }
}
