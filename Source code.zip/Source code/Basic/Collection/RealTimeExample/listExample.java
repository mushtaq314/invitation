package Collection.RealTimeExample;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
//1. Remove Duplicates from a List of Customer Emails
// Problem:
// You have a list of customer emails. Some customers have signed up multiple times. Remove the duplicate emails.

class ListExample{
    public static void main(String[] args) {
    
        ArrayList<String> emailList=new ArrayList<>(Arrays.asList("a@example.com", "b@example.com", "a@example.com", "c@example.com"));
     
        System.out.println(emailList.toString());
        System.out.println("here is the eamil list");
        for (String string : emailList) {
            System.out.println(string);
        }
        System.out.println("Removing the duplictes email::");
        Set<String> emailset=new HashSet<>(emailList);
        for (String string : emailset) {
            System.out.println(string);
        }

        emailList.add("g@mail.com");
                emailList.add("k@mail.com");
        System.out.println("wanted to remove it manually then ::");
        for (String string2 : emailset) {
           
        for (String string : emailList) {
            if(string.equals(string2))              //dont use contains bcz The .contains() method checks if one string is a substring of another. It's not an equality check."abc@example.com".contains("abc") ✅
            {
                System.out.println("alredy there ");
            }
            else{
                System.out.println("saved to db");
            }
        }

        
    }
}
}