package Collection.RealTimeExample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ListExample4 {

    public static void main(String[] args) {
        List<String> ordersSystem1 = new ArrayList<>(Arrays.asList(
            "Order001", "Order002", "Order003"
        ));

        List<String> ordersSystem2 = new ArrayList<>(Arrays.asList(
            "Order004", "Order005", "Order006"
        ));

        // Merge both lists
        
ordersSystem1.addAll(3, ordersSystem2);
ordersSystem2.addAll(ordersSystem2);
System.out.println(ordersSystem1.containsAll(ordersSystem2));
System.out.println(ordersSystem1);
System.out.println(ordersSystem2);


 List<Integer> ordersSystem3 = new ArrayList<>(Arrays.asList(
          1,2,3,4,5,6,7,7,7,6,5));
          ordersSystem3.addAll(ordersSystem3);
    }
}
