package Collection.Map;
import java.util.*;
public class MapExample {
    public static void main(String[] args) {
        Map<String, Integer> employeeAge = new HashMap<>();
        employeeAge.put("Alice", 25);
        employeeAge.put("Bob", 30);
        employeeAge.put("Charlie", 35);
        System.out.println("Employee Age Map: " + employeeAge);
        // Access by key
        System.out.println("Age of Alice:" +employeeAge.get("Alice"));  // 25
    }
}
