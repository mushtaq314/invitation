package Collection.Set.Enum;

import java.util.HashSet;
import java.util.Set;

/*In Java, enum is a special type of class that represents a collection of constants (unchangeable variables). An enum is implicitly final and static, meaning its values cannot be modified after they are defined. It is often used to represent a fixed set of related constants, such as days of the week, months of the year, or specific statuses.
*/
public class EnumInSetExample {

    // Step 1: Define an enum for Days of the Week
    enum Day {
        MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
    }

    public static void main(String[] args) {

        // Step 2: Create a Set to store enum values
        Set<Day> daysSet = new HashSet<>();

        // Step 3: Add elements to the Set
        daysSet.add(Day.MONDAY);
        daysSet.add(Day.WEDNESDAY);
        daysSet.add(Day.FRIDAY);
        daysSet.add(Day.SUNDAY);

        // Output the Set
        System.out.println("Days Set: " + daysSet);

        // Step 4: Check if a specific day is in the Set
        if (daysSet.contains(Day.MONDAY)) {
            System.out.println("Monday is in the Set.");
        }

        // Step 5: Remove a day from the Set
        daysSet.remove(Day.WEDNESDAY);
        System.out.println("After removing Wednesday: " + daysSet);

        // Step 6: Iterate over the Set
        System.out.print("Remaining days: ");
        for (Day day : daysSet) {
            System.out.print(day + " ");
        }
    }
}

