package Collection.Set;

import java.util.*;

public class SetExample {
    public static void main(String[] args) {
       Set<Integer> set1 = new HashSet<>(Arrays.asList(1, 2, 3, 4));
Set<Integer> set2 = new HashSet<>(Arrays.asList(3, 4, 5, 6));

// Union
Set<Integer> union = new HashSet<>(set1);
union.addAll(set2);     

// Intersection
Set<Integer> intersection = new HashSet<>(set1);
intersection.retainAll(set2);//Keeps only elements that are also in another collection

// Difference
Set<Integer> difference = new HashSet<>(set1);
difference.removeAll(set2);  //remove the elements from set2 all and the elements taht are common in set1

System.out.println("Union: " + union);           // [1, 2, 3, 4, 5, 6]  gives all the commin and unqiue
System.out.println("Intersection: " + intersection); // [3, 4]   //gives te common between both 
System.out.println("Difference: " + difference);     // [1, 2]   //remove the elements from set2 all and the elements taht are common in set1

    }
}