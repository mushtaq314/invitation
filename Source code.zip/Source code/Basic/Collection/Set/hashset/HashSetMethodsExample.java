package Collection.Set.hashset;

import java.util.HashSet;
import java.util.Arrays;
import java.util.Iterator;

public class HashSetMethodsExample {

    public static void main(String[] args) {

        // 1. Create a HashSet
        HashSet<String> fruits = new HashSet<>();

        // 2. add(E e) – Add elements to the set
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Cherry");
        fruits.add("Banana"); // Duplicate - will not be added

        System.out.println("After add(): " + fruits); // No duplicates

        // 3. size() – Get the number of elements
        System.out.println("Size of set: " + fruits.size());

        // 4. contains(Object o) – Check if an element exists
        System.out.println("Contains 'Banana'? " + fruits.contains("Banana"));
        System.out.println("Contains 'Orange'? " + fruits.contains("Orange"));

        // 5. isEmpty() – Check if the set is empty
        System.out.println("Is the set empty? " + fruits.isEmpty());

        // 6. iterator() – Iterate over elements
        System.out.println("Iterating over set:");
        Iterator<String> it = fruits.iterator();
        while (it.hasNext()) {
            System.out.println("  " + it.next());
        }

        // 7. toArray() – Convert to array
        Object[] fruitArray = fruits.toArray();
        System.out.println("Elements in array: " + Arrays.toString(fruitArray));

        // 8. remove(Object o) – Remove an element
        fruits.remove("Banana");
        System.out.println("After remove('Banana'): " + fruits);

        // 9. addAll(Collection) – Add multiple elements
        HashSet<String> moreFruits = new HashSet<>();
        moreFruits.add("Mango");
        moreFruits.add("Peach");
        fruits.addAll(moreFruits);
        System.out.println("After addAll(): " + fruits);

        // 10. containsAll(Collection) – Check if all elements exist
        System.out.println("Contains all from moreFruits? " + fruits.containsAll(moreFruits));

        // 11. removeAll(Collection) – Remove multiple elements
        fruits.removeAll(moreFruits);
        System.out.println("After removeAll(): " + fruits);

        // 12. clear() – Remove all elements
        fruits.clear();
        System.out.println("After clear(): " + fruits);
        System.out.println("Is the set empty now? " + fruits.isEmpty());
    }
}
