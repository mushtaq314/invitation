package Collection.Set.LInkedhash;

import java.util.LinkedHashSet;

public class SimpleLinkedHashSetExample {
    public static void main(String[] args) {
        
        // Creating a LinkedHashSet
        LinkedHashSet<String> fruits = new LinkedHashSet<>();

        // Adding elements to the LinkedHashSet
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");
        fruits.add("Mango");
        fruits.add("Apple"); // Duplicate element, will not be added

        // Display the LinkedHashSet
        System.out.println("Fruits in the set: " + fruits); // Output maintains insertion order

        // Check the size of the set
        System.out.println("Size of the set: " + fruits.size());

        // Check if an element exists in the set
        System.out.println("Does the set contain 'Banana'? " + fruits.contains("Banana"));

        // Remove an element
        fruits.remove("Orange");
        System.out.println("After removing 'Orange': " + fruits);

        // Iterating over the elements using for-each loop
        System.out.println("Iterating through the set:");
        for (String fruit : fruits) {
            System.out.println(fruit);
        }

        // Check if the set is empty
        System.out.println("Is the set empty? " + fruits.isEmpty());

        // Clear all elements in the set
        fruits.clear();
        System.out.println("After clearing the set: " + fruits);
    }
}
