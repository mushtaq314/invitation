package Collection.Set;
import java.util.*;

public class SetMethodsExample {
 public static void main(String[] args) {
        Set<String> fruits = new HashSet<>();

        // 1. add()
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Orange");

        // 2. addAll()
        Set<String> tropicalFruits = new HashSet<>();
        tropicalFruits.add("Mango");
        tropicalFruits.add("Pineapple");
        fruits.addAll(tropicalFruits);

        // 3. contains()
        System.out.println("Contains Apple? " + fruits.contains("Apple")); // true

        // 4. containsAll()
        System.out.println("Contains all tropical fruits? " + fruits.containsAll(tropicalFruits)); // true

        // 5. size()
        System.out.println("Total fruits: " + fruits.size()); // 5

        // 6. isEmpty()
        System.out.println("Is the set empty? " + fruits.isEmpty()); // false

        // 7. remove()
        fruits.remove("Banana");
        System.out.println("After removing Banana: " + fruits);

        // 8. removeAll()
        fruits.removeAll(tropicalFruits);
        System.out.println("After removing tropical fruits: " + fruits);

        // 9. addAll again for next examples
        fruits.addAll(Arrays.asList("Apple", "Banana", "Cherry"));

        // 10. retainAll()
        Set<String> favorites = new HashSet<>(Arrays.asList("Apple", "Kiwi"));
        fruits.retainAll(favorites); // Keeps only common
        System.out.println("After retainAll (common with favorites): " + fruits);

        // 11. toArray()
        Object[] fruitArray = fruits.toArray();
        System.out.println("Array: " + Arrays.toString(fruitArray));

        // 12. iterator()
        System.out.print("Iterating with iterator: ");
        Iterator<String> iterator = fruits.iterator();
        while (iterator.hasNext()) {
            System.out.print(iterator.next() + " ");
        }
        System.out.println();

        // 13. clear()
        fruits.clear();
        System.out.println("After clear(): " + fruits); // []

        // 14. equals()
        Set<String> set1 = new HashSet<>(Arrays.asList("A", "B"));
        Set<String> set2 = new HashSet<>(Arrays.asList("B", "A"));
        System.out.println("set1 equals set2? " + set1.equals(set2)); // true

        // 15. hashCode()
        System.out.println("HashCode of set1: " + set1.hashCode());

        // 16. stream()
        set1.stream().forEach(e -> System.out.println("Stream value: " + e));
    }
}
