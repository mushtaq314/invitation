package Collection.List;
import java.util.*;
public class ListExample {
    public static void main(String[] args) {
        List<String> fruits = new ArrayList<>();//ArrayLIst//linkdLIst//
        fruits.add("Apple");
        fruits.add("Banana");
        fruits.add("Mango");
        fruits.add("Banana");  // Duplicates allowed in List

        System.out.println(fruits);  // [Apple, Banana, Mango, Banana]

        // Access by index
        System.out.println("First fruit: " + fruits.get(0));  // Apple
System.out.println("-----------Array List---------");
        for (String string : fruits) {
            System.out.println(string);
        }

        for (int i = 0; i < fruits.size()-1; i++) {
            System.out.println(fruits.get(i));
        }
       System.out.println("-----------Linked List---------");
        List<Integer> rollNo=new LinkedList<Integer>();
        rollNo.add(21);
        rollNo.add(22);
        rollNo.add(23);
        rollNo.add(24);
        rollNo.add(25);

        for (Integer integer : rollNo) {
            System.out.println(integer);
        }
        System.out.println(rollNo.size());
       Integer[] boxedArray = rollNo.toArray(new Integer[0]);

       
    }
}