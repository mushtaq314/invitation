package Collection.List.Basic;
import java.util.ArrayList;
//import java.util.Collections;
//import java.util.Collection;
import java.util.List;
import java.util.Arrays;
import java.util.LinkedList;

public class MethodsList {
    public static void main(String[] args) {
 List<Integer> list = new ArrayList<>();

        // Add elements
        list.add(5);
        list.add(10);
        list.add(15);
        list.add(20);
        
        // Display the list
        System.out.println("List: " + list);
        
        // Remove element by index
        list.remove(2);  // Removes element at index 2 (15)
        
        // Check size
        System.out.println("Size after removal: " + list.size());
        
        // Access element
        System.out.println("Element at index 1: " + list.get(1));
        
        // Check if list contains an element
        System.out.println("Contains 10: " + list.contains(10));
        
        // Sort the list
        list.sort(Integer::compareTo);  // Sort in ascending order
        System.out.println("Sorted List: " + list);
        
        // Sublist operation
        List<Integer> subList = list.subList(0, 2);
        System.out.println("Sublist: " + subList);
        
        // Clear the list
        list.clear();
        System.out.println("List after clear: " + list);
                // Convert ArrayList to LinkedList
        List<Integer> linkedList = new LinkedList<>(list);
        
        // Print the LinkedList
        System.out.println("Converted LinkedList: " + linkedList);

    }
}
