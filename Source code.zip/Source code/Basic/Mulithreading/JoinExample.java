package Mulithreading;
import java.lang.*;

class MyThread extends Thread {
    public void run() {
        System.out.println(getName() + " started");
        try {
            Thread.sleep(2000);  // simulate work
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(getName() + " finished");
    }
}

public class JoinExample {
    public static void main(String[] args) throws InterruptedException {
        MyThread t1 = new MyThread();
        t1.start();

        System.out.println("Main thread waiting for t1 to finish");
        t1.join();  // Main thread waits here until t1 finishes

        System.out.println("t1 finished, main thread continues");
    }
}
