package Mulithreading;

class FileDownloader extends Thread {
    private String fileName;

    public FileDownloader(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void run() {
        System.out.println("Downloading " + fileName + " by " + Thread.currentThread().getName());
        // Simulate download
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(fileName + " downloaded by " + Thread.currentThread().getName());
    }
}

public class ThreadRealTime {
     public static void main(String[] args) {
        FileDownloader d1 = new FileDownloader("File1.zip");
        FileDownloader d2 = new FileDownloader("File2.zip");

        d1.start();
        d2.start();
     }
}
