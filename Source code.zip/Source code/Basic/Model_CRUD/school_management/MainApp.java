package Model_CRUD.school_management;

import Model_CRUD.school_management.model.Student;
import Model_CRUD.school_management.model.Subject;
import Model_CRUD.school_management.model.Teacher;
import  Model_CRUD.school_management.service.StudentService;
import Model_CRUD.school_management.service.SubjectService;
import  Model_CRUD.school_management.service.TeacherService;

import java.util.Arrays;

public class MainApp {
    public static void main(String[] args) {
        
        StudentService studentService = new StudentService();
        TeacherService teacherService = new TeacherService();

        // Create subjects
        Subject math = new Subject("Math", "Mr. Smith");
        Subject science = new Subject("Science", "Ms. Johnson");

        // Create students with subjects
        Student student1 = new Student(1, "Alice", 14, "8th", Arrays.asList(math, science));
        Student student2 = new Student(2, "Bob", 15, "9th", Arrays.asList(science));

        // Add students
        studentService.addStudent(student1);
        studentService.addStudent(student2);

        // Create teachers
        Teacher teacher1 = new Teacher(1, "Mr. Smith", Arrays.asList(math));
        Teacher teacher2 = new Teacher(2, "Ms. Johnson", Arrays.asList(science));

        // Add teachers
        teacherService.addTeacher(teacher1);
        teacherService.addTeacher(teacher2);

        // Display all students and teachers
        System.out.println("All students:");
        studentService.displayAllStudents();

        System.out.println("\nAll teachers:");
        teacherService.displayAllTeachers();

        // Update student
        studentService.updateStudent(1, "Alice Cooper", "9th");
        System.out.println("\nAfter updating Alice:");
        studentService.displayAllStudents();

        // Delete teacher
        teacherService.deleteTeacher(2);
        System.out.println("\nAfter deleting Ms. Johnson:");
        teacherService.displayAllTeachers();

        // === SUBJECT CRUD DEMO ===
SubjectService subjectService = new SubjectService();

// Create subjects
Subject history = new Subject("History", "Mrs. Clark");
Subject english = new Subject("English", "Mr. Watson");

subjectService.addSubject(history);
subjectService.addSubject(english);

// Read
System.out.println("\nGetting subject by name:");
System.out.println(subjectService.getSubjectByName("English"));

// Update
subjectService.updateSubject("History", "Dr. Brown");

// Delete
subjectService.deleteSubject("English");

// Display all
System.out.println("\nAll subjects after changes:");
subjectService.displayAllSubjects();
    }
}
