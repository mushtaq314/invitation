package Model_CRUD.school_management.service;



import Model_CRUD.school_management.model.Subject;

import java.util.ArrayList;
import java.util.List;

public class SubjectService {
    private List<Subject> subjects = new ArrayList<>();

    // CREATE
    public void addSubject(Subject subject) {
        subjects.add(subject);
        System.out.println("Subject added: " + subject.getName());
    }

    // READ
    public Subject getSubjectByName(String name) {
        for (Subject subject : subjects) {
            if (subject.getName().equalsIgnoreCase(name)) {
                return subject;
            }
        }
        return null;
    }

    // UPDATE
    public boolean updateSubject(String name, String newTeacherName) {
        Subject subject = getSubjectByName(name);
        if (subject != null) {
            subject.setTeacherName(newTeacherName);
            System.out.println("Updated teacher for subject: " + name);
            return true;
        }
        return false;
    }

    // DELETE
    public boolean deleteSubject(String name) {
        return subjects.removeIf(s -> s.getName().equalsIgnoreCase(name));
    }

    // DISPLAY ALL
    public void displayAllSubjects() {
        if (subjects.isEmpty()) {
            System.out.println("No subjects available.");
        } else {
            for (Subject s : subjects) {
                System.out.println(s);
            }
        }
    }
}

