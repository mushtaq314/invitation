package Model_CRUD.healthcare_management.service;




import Model_CRUD.healthcare_management.model.Appointment;
import java.util.ArrayList;
import java.util.List;

public class AppointmentService {
    private List<Appointment> appointments = new ArrayList<>();

    public void addAppointment(Appointment a) {
        appointments.add(a);
    }

    public boolean deleteAppointment(int id) {
        return appointments.removeIf(a -> a.getId() == id);
    }

    public void displayAll() {
        for (Appointment a : appointments) {
            System.out.println(a);
        }
    }
}
