package Model_CRUD.healthcare_management.service;


import Model_CRUD.healthcare_management.model.Doctor;
import java.util.ArrayList;
import java.util.List;

public class DoctorService {
    private List<Doctor> doctors = new ArrayList<>();

    public void addDoctor(Doctor doctor) {
        doctors.add(doctor);
    }

    public Doctor getDoctorById(int id) {
        for (Doctor d : doctors) {
            if (d.getId() == id) return d;
        }
        return null;
    }

    public boolean updateDoctor(int id, String newName, String newSpec) {
        Doctor doctor = getDoctorById(id);
        if (doctor != null) {
            doctor.setName(newName);
            doctor.setSpecialization(newSpec);
            return true;
        }
        return false;
    }

    public boolean deleteDoctor(int id) {
        return doctors.removeIf(d -> d.getId() == id);
    }

    public void displayAll() {
        for (Doctor d : doctors) {
            System.out.println(d);
        }
    }
}
