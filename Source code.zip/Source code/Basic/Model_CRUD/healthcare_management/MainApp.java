package Model_CRUD.healthcare_management;

import Model_CRUD.healthcare_management.model.*;
import Model_CRUD.healthcare_management.service.*;

public class MainApp {
    public static void main(String[] args) {

        // Services
        PatientService patientService = new PatientService();
        DoctorService doctorService = new DoctorService();
        AppointmentService appointmentService = new AppointmentService();

        // Add patients
        Patient p1 = new Patient(1, "Alice", 30, "Flu");
        Patient p2 = new Patient(2, "Bob", 45, "Diabetes");
        patientService.addPatient(p1);
        patientService.addPatient(p2);

        // Add doctors
        Doctor d1 = new Doctor(1, "Dr. Smith", "General");
        Doctor d2 = new Doctor(2, "Dr. Emily", "Endocrinologist");
        doctorService.addDoctor(d1);
        doctorService.addDoctor(d2);

        // Add appointments
        Appointment a1 = new Appointment(1, p1, d1, "2025-09-25");
        Appointment a2 = new Appointment(2, p2, d2, "2025-09-26");
        appointmentService.addAppointment(a1);
        appointmentService.addAppointment(a2);

        // Display all data
        System.out.println("== Patients ==");
        patientService.displayAll();

        System.out.println("\n== Doctors ==");
        doctorService.displayAll();

        System.out.println("\n== Appointments ==");
        appointmentService.displayAll();

        // Example: update patient
        patientService.updatePatient(1, "Alice Johnson", 31, "Recovered Flu");
    }
}
