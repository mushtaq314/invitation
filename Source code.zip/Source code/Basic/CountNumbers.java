import java.util.Scanner;

class CountNumbers{
    public static void main(String[] args)
    {
        System.out.println("Enter the number ");
        Scanner scn=new Scanner(System.in);
        int inputNumber=scn.nextInt();

        countingTheNumber(inputNumber);

    }
    public static void countingTheNumber(int CheckNumber)
    {
        System.out.println("counting the nummbers..........");
        int c=0;
        for(int i=CheckNumber;i!=0;)
        {
            c++;
            i=i/10;
        }
        System.out.println("number of didgit are::"+c);
        
    }
}