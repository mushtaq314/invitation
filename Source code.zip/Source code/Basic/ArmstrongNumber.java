import java.util.*;
public class ArmstrongNumber {
    
public static void main(String []args)
{
    Scanner scn=new Scanner(System.in);
    System.out.println("ENter the Number");
    int number=scn.nextInt();

    //153  cont 3  1*3+5*3+3*3 
    int temp=number;
    int c=0;
     while(temp!=0)
     {
        //int num=temp%10;
        temp=temp/10;
    c++; 
    }

    System.out.println("count is "+c);
    temp=number;
    double  total=0;
    while(temp!=0)
    {
        int digit=temp%10;
         total=total+Math.pow(digit,3);
        temp=temp/10;   
    }
    if(total==number)
    {
        System.out.println("Number is Armstrong"+number);

    }
    else{
        System.out.println("number is not Armstring "+number);
    }    
}


}
