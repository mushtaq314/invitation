package StreamApi;


    public class StreamRunner {
    public static void main(String[] args) {
        System.out.println("=== Filter ===");
        FilterExample.run();

        System.out.println("\n=== Map ===");
        MapExample.run();

        System.out.println("\n=== ForEach ===");
        ForEachExample.run();

        System.out.println("\n=== Sorted ===");
        SortedExample.run();

        System.out.println("\n=== Distinct ===");
        DistinctExample.run();

        System.out.println("\n=== Reduce ===");
        ReduceExample.run();

        System.out.println("\n=== GroupingBy ===");
        GroupingByExample.run();

        System.out.println("\n=== FlatMap ===");
        FlatMapExample.run();
    }
}

