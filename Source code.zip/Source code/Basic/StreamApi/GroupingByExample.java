package StreamApi;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class GroupingByExample {
     public static void run() {
        List<String> names = List.of("Alice", "Anna", "Bob", "Brian");

        Map<Character, List<String>> grouped =
            names.stream()
                 .collect(Collectors.groupingBy(name -> name.charAt(0)));

        System.out.println(grouped);
    }
}
