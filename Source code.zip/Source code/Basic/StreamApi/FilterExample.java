package StreamApi;

import java.util.List;
import java.util.stream.Collectors;

import javax.lang.model.util.Elements;
import javax.swing.text.html.parser.Element;

public class FilterExample {
        public static void run() {
        List<String> names = List.of("Alice", "Bob", "Alex", "Brian");

        names.stream().filter(name -> name.startsWith("A")).forEach(System.out::println);  // Alice, Alex
        List<String> sortedString=names.stream().filter(name -> name.startsWith("A")).collect(Collectors.toList());
     
        System.out.println("-- sorted using the string --");
        for (String string : sortedString) {
                System.out.println(string);
             }
      


          System.out.println("--List Containe the Alice--"); 
     //    List<String> sameEle=names.stream().filter(name->name.contains("Alice")).collect(Collectors.toList());
            boolean  sameEle=names.stream().allMatch(name->name.contains("ram"));
           if (sameEle) {
            System.out.println("person exist");
           }
           else{
            System.out.println("value does ot exist");
           }

              List<Integer> ELements = List.of(1,2,3,4,5,7,9,7,6,45);

              List<Integer> oddEle=ELements.stream().filter(Elements->Elements%2!=0).distinct().collect(Collectors.toList());
              System.out.println("--List of Odd ELements withiut duplicates");
              for (Integer integer : oddEle) {
                System.out.println(integer);
              }
               

    }
}
