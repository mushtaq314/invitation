package StreamApi;

import java.util.List;

public class ForEachExample {
     public static void run() {
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        numbers.stream()
               .forEach(n -> System.out.println("Number: " + n));
    }
}
