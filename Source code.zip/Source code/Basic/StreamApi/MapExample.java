package StreamApi;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class MapExample {
     public static void run() {
        List<String> words = List.of("java", "stream", "api");
        System.out.println("map converting the lowercse into upperase ::");
       words.stream().map(String::toUpperCase).forEach(System.out::println);  
  
     System.out.println("Map removig the letter");
    List<String> filterWords = words.stream()
    .map(word -> word.trim().replaceAll("[ea]", ""))
    .collect(Collectors.toList());


      for (String string : filterWords) {
          System.out.println(string);
      }
}
  }