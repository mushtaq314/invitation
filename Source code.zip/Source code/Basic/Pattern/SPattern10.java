package Pattern;

class SPattern10 {
    public static void main(String args[]) {
        int n = 5;

        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                // Check for corners
                if ((i == 1 || i == n) && (j == 1 || j == n)) {
                    System.out.print("_");
                }
                // Top or bottom border (excluding corners)
                else if (i == 1 || i == n) {
                    System.out.print("*");
                }
                // Left or right border (excluding corners)
                else if (j == 1 || j == n) {
                    System.out.print("*");
                }
                // Inside of the box
                else {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
    }
}
