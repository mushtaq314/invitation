package Pattern;
import Pattern.SPattern1;

class SPattern2
{

    public static void main(String []args)
    {
        SPattern1 s=new SPattern1();
        System.out.println(s);
        for(int i=1;i<=10;i++)
        {
            for(int j=10;j>=i;j--)
            {
             System.out.print("*");
            }
            System.out.println("");
        }
    }
}