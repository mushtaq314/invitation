package ExceptionHandling;
//1. Write a program to divide two numbers and handle ArithmeticException if the denominator is zero.

public class ArithmeticException1 {
  
    public static void additionMethod()
    {
       try
       {  
        int num1=2/0;
       }
       catch(ArithmeticException e)
       {
        System.out.println("Exception in additionMethod "+e.getMessage());
        e.printStackTrace();

        System.out.println("-----------------------------------------");
       }
    }

    public static void main(String[] args) {
        int number1=2;
        int number2=4;
try{
         additionMethod();
        int number3=number1/number2;
        System.out.println(number3);
         number3=number1/4;//why this line is not executing ??
        System.out.println(number3);
}
catch(ArithmeticException e)
{
    System.out.println("Exception: " + e.getMessage());
            e.printStackTrace();
            System.out.println("Don't divide by zero");
}
int number3=number1/4;  //this line is executiong after the try get catch and cam e out of it then prunt thsi line 
        System.out.println("out of the try and perform "+number3);
        
    }
}
