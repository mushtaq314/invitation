package ExceptionHandling.ThrowsInputo;
//10. Create a method that throws IOException. Handle the exception in the main() method using throws.

import java.util.InputMismatchException;
import java.util.Scanner;

public class ThrowIandOException {
    
    public static void calling_Input_Output_ExptionCatch()
    {
        
        Scanner scn=new Scanner(System.in);
        String name=scn.nextLine();
        throw new InputMismatchException("input mismatch exception");
      
                 
    }
    public static void main(String[] args) {
       
        try
        {
         calling_Input_Output_ExptionCatch();
                  
        } catch (InputMismatchException e) {
            // TODO: handle exception
            System.out.println(e);
        }}
}
