package OOP.Inhertance.Singlelevel;
import OOP.Inhertance.Singlelevel.User;
import OOP.Inhertance.Singlelevel.UserLogin;
public class Main {
    public static void main(String[] args) {
          UserLogin user = new UserLogin();

        user.setUsername("user123");
        user.setPassword("abc125");

        System.out.println("Username: " + user.getUsername());
        System.out.println("Password: " + user.getPassword());

        if (user.validateLogin("user123", "abc125")) {
            System.out.println("Login successful.");
        } else {
            System.out.println("Login failed.");
        }
    }
    
}
