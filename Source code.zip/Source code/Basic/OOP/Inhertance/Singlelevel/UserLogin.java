package OOP.Inhertance.Singlelevel;
import OOP.Inhertance.Singlelevel.User;
public class UserLogin extends User {
    
     // Method to check login credentials
    public boolean validateLogin(String username, String password) {
        return getUsername() != null && getPassword() != null &&
               getUsername().equals(username) && getPassword().equals(password);
    }
}
