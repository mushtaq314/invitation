package OOP.Accsess_Modifiers;

public class AccessMofiersClass {
    private int  RollNO=21;  //only within the same class
    protected String name="kiran";
    public String address="pune Kharadi";
     double price=12.98;

}

class subclass extends AccessMofiersClass{
    public static void main(String args[])
    {
         AccessMofiersClass amc=new AccessMofiersClass();
//       System.out.println("Accesed the (protected) var from withinthe same class acces through subclass  within same package::"+amc.RollNO);

    System.out.println("Accesed the (protected) var from withinthe same class acces through subclass  within same package::"+amc.name);

    System.out.println("Accesed the (public) var from another subclass class in within same package::"+amc.address);  //can access public everywhere within same and outside the package . 
  
System.out.println("Accesed the (Default) var from withinthe same class acces through subclass and same package::"+amc.price);


    }
}
