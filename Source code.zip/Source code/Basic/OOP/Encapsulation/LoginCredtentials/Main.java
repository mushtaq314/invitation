package OOP.Encapsulation.LoginCredtentials;
import OOP.Encapsulation.LoginCredtentials.Model;;
public class Main {
    public static void main(String[] args) {
        
     Model m=new Model();

     m.setUsername("1093109");
     m.setPassword("abc123");

    System.out.println("username is::"+m.getUsername());
    System.out.println("Password is ::"+m.getPassWord());

   if (m.validateLogin("user123", "abc123")) {
            System.out.println("Login successful.");
        } else {
            System.out.println("Login failed.");
        }

    }
    
}
