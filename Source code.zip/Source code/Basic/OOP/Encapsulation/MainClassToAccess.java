package OOP.Encapsulation;
import OOP.Encapsulation.TheoryEncapsulatoionImp;

import javax.naming.Context;

import OOP.Accsess_Modifiers.AccessMofiersClass;;
// You don’t access the variable directly — you access it through a public method that lives inside the class where the private variable exists.
// This is exactly what Encapsulation means:
// Hide the data, expose only controlled access.

public class MainClassToAccess extends AccessMofiersClass {
    
    public static void main(String args[])
    {
        TheoryEncapsulatoionImp TEI=new TheoryEncapsulatoionImp();
        // int RollNo=TEI.getrollno();//get roll no
        // System.out.println("Roll No is ::"+RollNo);
        String Name="kiran";
        TEI.setName(Name);
        System.out.println("Name:"+TEI.getName());


        //checking the access Modifiers 
        System.out.println("checking the access Mofiers");
        //int a=TEI.Rollno;  //accesing the private var from outside another class encapsu;letd class can happen only using the public (SETTER AND GETTER)




        AccessMofiersClass amc=new AccessMofiersClass();
     //ERROR---System.out.println("Accesed the (protected) var from another class in another class within same package::"+amc.name);  //ERROR ** bcz we cant access protected var outsuide the package 
     

//For protected:
//   Context                    	  Can Access?
// Same class                   	  ✅ Yes
// Same package	                      ✅ Yes
// Subclass (same package)      	  ✅ Yes
// Subclass (different package)	      ✅ Yes ✅ BUT ONLY through inheritance (not through an object)
// Non-subclass (different package)	  ❌ No
     MainClassToAccess obj = new MainClassToAccess();
     System.out.println("Accesed the (protected) var from another class in another class within same package::"+obj.name);   
     
        System.out.println("Accesed the (public) var from another class in another class within same package and outside the package::"+amc.address);  //can access public everywhere within same and outside the package . 
 //   **ERROR  System.out.println("Accesed the (Default) var from within the same class acces through another class file and differnt package::"+amc.price);  //error cannot be access
}
    
    }

