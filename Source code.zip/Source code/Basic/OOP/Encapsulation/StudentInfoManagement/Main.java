package OOP.Encapsulation.StudentInfoManagement;
import java.util.Scanner;

import OOP.Encapsulation.StudentInfoManagement.Model;
public class Main {
    public static void main(String []args)
    {
         System.out.println("Enter the student Details::");
         Scanner scn=new Scanner(System.in);
         
         System.out.println("enter the name");
         String name=scn.nextLine();
         
         System.out.println("enter the age of student");
         int age=scn.nextInt();

         System.out.println("enter the marks");
         int marks=scn.nextInt();

         Model m=new Model();

         m.setName(name);
         m.setAge(age);
         m.setMarks(marks);
         
        System.out.println(m.getName());
        System.out.println(m.getAge());
        System.out.println(m.getMarks());
     

    }
}
