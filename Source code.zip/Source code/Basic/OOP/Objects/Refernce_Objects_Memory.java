package OOP.Objects;

public class Refernce_Objects_Memory {
    
    public static void main(String []args)
    {
        int num;//primitive memory at the compile time
        num=1;//primitive same memory at the compile time
        num=2;      //primitive same memory at the compile time
           String s1 = "hello";  // "hello" stored in String Pool, s1 points to it
        String s2 = "hello";  // s2 points to the same "hello" in the String Pool (no new object created)

        System.out.println(s1 == s2);  // true, both refer to the same object in the String Pool

        String s3 = new String("hello"); // creates a new String object in heap (not in String Pool)
        System.out.println(s1 == s3);  // false, s3 points to a different object

        String s4 = s3.intern(); 
        // intern() checks if "hello" exists in String Pool
        // If yes, returns reference to the pooled String object
        System.out.println(s1 == s4);  // true, s4 now points to String Pool object

     
        Refernce_Objects_Memory rom=new Refernce_Objects_Memory();//memeory address created 
    
        System.out.println(rom);


    //    parentclass pc=new parentclass();  //here created the object of parent class in child class method so i can acess which members of parent and child class through it 
//     parentclass	new parentclass()	Only parentclass members
//parentclass pc=	new childclass()	parentclass members (overridden methods call child's version)
//childclass  cc=	new childclass()	Both parentclass and childclass members
 //childclass  cc=	new parentclass()

        
    }
}

