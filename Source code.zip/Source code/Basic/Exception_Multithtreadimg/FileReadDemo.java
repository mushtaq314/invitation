package Exception_Multithtreadimg;
// Write a Java program that reads 3 different files using 3 separate threads.
// Each thread should read a file line-by-line and print the contents.
// Handle exceptions such as FileNotFoundException and IOException.

import java.io.*;

// Thread class to read a file line-by-line
class FileManipulationClass extends Thread {
    private final String path;
    private final String threadName;

    public FileManipulationClass(String path, String threadName) {
        this.path = path;
        this.threadName = threadName;
    }

    @Override
    public void run() {
        BufferedReader reader = null;
        try {
            System.out.println(threadName + ": Opening file " + path);
            reader = new BufferedReader(new FileReader(path));
            String line;

            while ((line = reader.readLine()) != null) {
                System.out.println(threadName + ": " + line);
            }
            System.out.println(threadName + ": Finished reading file.");
        } catch (FileNotFoundException e) {
            System.out.println(threadName + ": File not found: " + path);
        } catch (IOException e) {
            System.out.println(threadName + ": IO Error reading file: " + path);
        } finally {
            try {
                if (reader != null) reader.close();
            } catch (IOException e) {
                System.out.println(threadName + ": Error closing file reader");
            }
        }
    }
}

public class FileReadDemo {
    public static void main(String[] args) {
        // Pass actual file paths on your system here
        FileManipulationClass t1 = new FileManipulationClass("D:\\\\demo\\\\Pract\\\\Java Pract\\\\Source code\\\\Basic\\\\ExceptionHandling\\\\sql.txt", "Thread-1");
        FileManipulationClass t2 = new FileManipulationClass("D:\\\\demo\\\\Pract\\\\Java Pract\\\\Source code\\\\Basic\\\\ExceptionHandling\\\\sql.txt", "Thread-2");
        FileManipulationClass t3 = new FileManipulationClass("D:\\\\demo\\\\Pract\\\\Java Pract\\\\Source code\\\\Basic\\\\ExceptionHandling\\\\sql.txt", "Thread-3");

        t1.start();
        t2.start();
        t3.start();
    }
}
