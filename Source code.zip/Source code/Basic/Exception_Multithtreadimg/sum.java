package Exception_Multithtreadimg;
class sum{
    public static void main(String[] args) {
        int num=2;
        System.out.println(num/0);
    }
}