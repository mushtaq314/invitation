import java.util.*;

class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter the number: ");
        int num = scn.nextInt();
        int originalNum = num;
        int rev = 0;

        while (num != 0) {
            int digit = num % 10;       
            System.out.println("Get last digit"+digit);
            rev = rev * 10 + digit;       
            System.out.println("// Build the reversed number"+digit);
          
            num = num / 10;               
          System.out.println("// Remove last digit"+digit);
          
         }

      
        if (originalNum == rev) {
            System.out.println(originalNum + " is a Pali.");
        } else {
            System.out.println(originalNum + " is NOT a Pali.");
        }
    }
}


