package AccessMofiers.packageone;

public class SamePackageTest {
    public static void main(String[] args) {
        DemoClass obj = new DemoClass();

        // Non-static vars/methods
        System.out.println(obj.publicVar);       // ✅ accessible
        // System.out.println(obj.privateVar);   // ❌ not accessible
        System.out.println(obj.protectedVar);    // ✅ accessible
        System.out.println(obj.defaultVar);      // ✅ accessible

        obj.publicMethod();                       // ✅ accessible
        // obj.privateMethod();                   // ❌ not accessible
        obj.protectedMethod();                    // ✅ accessible
        obj.defaultMethod();                      // ✅ accessible

        // Static vars/methods
        System.out.println(DemoClass.publicStaticVar);      // ✅ accessible
        // System.out.println(DemoClass.privateStaticVar);  // ❌ not accessible
        System.out.println(DemoClass.protectedStaticVar);   // ✅ accessible
        System.out.println(DemoClass.defaultStaticVar);     // ✅ accessible

        DemoClass.publicStaticMethod();           // ✅ accessible
        // DemoClass.privateStaticMethod();       // ❌ not accessible
        DemoClass.protectedStaticMethod();        // ✅ accessible
        DemoClass.defaultStaticMethod();          // ✅ accessible
    }
}