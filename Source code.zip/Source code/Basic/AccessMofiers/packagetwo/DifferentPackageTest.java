package AccessMofiers.packagetwo;



import AccessMofiers.packageone.DemoClass;

public class DifferentPackageTest {
    public static void main(String[] args) {
        DemoClass obj = new DemoClass();

        System.out.println(obj.publicVar);       // ✅ accessible
        // System.out.println(obj.privateVar);   // ❌ not accessible
        // System.out.println(obj.protectedVar); // ❌ not accessible
        // System.out.println(obj.defaultVar);   // ❌ not accessible

        obj.publicMethod();                       // ✅ accessible
        // obj.privateMethod();                   // ❌ not accessible
        // obj.protectedMethod();                 // ❌ not accessible
        // obj.defaultMethod();                   // ❌ not accessible

        System.out.println(DemoClass.publicStaticVar);     // ✅ accessible
        // System.out.println(DemoClass.privateStaticVar); // ❌ not accessible
        // System.out.println(DemoClass.protectedStaticVar);// ❌ not accessible
        // System.out.println(DemoClass.defaultStaticVar); // ❌ not accessible

        DemoClass.publicStaticMethod();           // ✅ accessible
        // DemoClass.privateStaticMethod();       // ❌ not accessible
        // DemoClass.protectedStaticMethod();     // ❌ not accessible
        // DemoClass.defaultStaticMethod();       // ❌ not accessible
    }
}
