

class Anagram{
    public static void main(String []args)
    {

         String str1="enlist";

         String str2="inlets";

         int c=0;
         if(str1.length()==str2.length())
         {
             System.out.println("SAME LENGTH "+str1.length());
       
        for(int i=0;i<=str1.length()-1;i++)
        {
                    for(int j=0;j<=str2.length()-1;j++)
                    {
                        if(str1.charAt(i)==str2.charAt(j))
                        {
                            c++;
                        }
                    }
        }
        if(str1.length()==c++)
        {
            System.out.println("it is anagram");
        }
        else{
            System.out.println("It is not anagram");
        }
    }
    else{
        System.out.println("It is Mismatch");
    }
     
    }
}